
// Quote calculator
document.getElementById('quoteForm')?.addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const lawnSize = document.getElementById('lawnSize').value;
    const serviceType = document.getElementById('serviceType').value;
    
    try {
        const response = await fetch('/api/calculate-quote', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                lawn_size: parseFloat(lawnSize),
                service_type: serviceType
            })
        });
        
        const result = await response.json();
        
        document.getElementById('quoteDetails').innerHTML = `
            <strong>Service:</strong> ${result.service}<br>
            <strong>Lawn Size:</strong> ${result.size} sq ft<br>
            <strong>Estimated Price:</strong> $${result.price} per visit
        `;
        
        document.getElementById('quoteResult').style.display = 'block';
    } catch (error) {
        console.error('Error calculating quote:', error);
    }
});

// Contact form
document.getElementById('contactForm')?.addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = new FormData();
    formData.append('name', document.getElementById('name').value);
    formData.append('email', document.getElementById('email').value);
    formData.append('service', document.getElementById('service').value);
    formData.append('message', document.getElementById('message').value);
    
    try {
        const response = await fetch('/contact', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        const resultDiv = document.getElementById('contactResult');
        resultDiv.innerHTML = `<div class="alert alert-success">${result.message}</div>`;
        resultDiv.style.display = 'block';
        
        document.getElementById('contactForm').reset();
    } catch (error) {
        console.error('Error submitting form:', error);
    }
});

// Service selection from services page
function selectService(serviceType) {
    window.location.href = `/quote?service=${serviceType}`;
}

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});
